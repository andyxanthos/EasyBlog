## example3.md


### ZOMG, 3 examples.