## example2.md

*markdown is fun*

Is this a new paragraph?


Is *this* a new paragraph?